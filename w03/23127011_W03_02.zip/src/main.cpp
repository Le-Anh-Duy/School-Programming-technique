#include <iostream>
#include "../headers/add_one.hpp"
#include "../headers/palindrome.hpp"

int main() {
    // char s[200];
    // std::cin.getline(s, 100);
    // // std::cout << s;
    // std::cout << isPalindrome(s);
}