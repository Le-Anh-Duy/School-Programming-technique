#include "../headers/add_one.hpp"

void addOne(int *ptrNum) {
    (*ptrNum) ++;
}